#include <Wire.h>
#include <MPU6050.h>

MPU6050 mpu;
const int BUTTON_PIN = 4;

float lastAccelMag = 0;
unsigned long alertStartTime = 0;
bool alertActive = false;

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Wire.begin();
  mpu.initialize();
  Serial.println("Ring online. Monitoring...");
}

void loop() {
  int16_t ax, ay, az;
  mpu.getAcceleration(&ax, &ay, &az);

  // Convert raw values to a rough magnitude (g-force proxy)
  float accelMag = sqrt((float)ax*ax + (float)ay*ay + (float)az*az) / 16384.0;

  // "Jerk" = how sharply acceleration changed since last reading
  float jerk = abs(accelMag - lastAccelMag);
  lastAccelMag = accelMag;

  bool buttonPressed = (digitalRead(BUTTON_PIN) == LOW);
  bool struggleDetected = (jerk > 0.6);   // tune this threshold after testing

  if ((buttonPressed || struggleDetected) && !alertActive) {
    alertActive = true;
    alertStartTime = millis();
    Serial.println("=== PHASE 1: Trigger detected. Starting recording + GPS lock ===");
    Serial.print("Trigger source: ");
    Serial.println(buttonPressed ? "Manual button" : "AI motion detection");
  }

  if (alertActive) {
    unsigned long elapsed = millis() - alertStartTime;
    if (elapsed > 5000 && elapsed < 5200) {
      Serial.println("=== PHASE 2: 5s elapsed. Notifying family with live GPS ===");
    }
    if (elapsed > 10000 && elapsed < 10200) {
      Serial.println("=== PHASE 3: 10s elapsed. Dispatching alert to police (ERSS-112) ===");
      alertActive = false; // reset for demo purposes
    }
  }

  delay(100);
}
